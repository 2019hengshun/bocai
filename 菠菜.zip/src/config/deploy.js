var newwork;
var options;

network = {
  blockchain: 'eos',
  host: '129.28.69.40',
  port: 8888,
  protocol: 'http',
  chainId: "3670d2e3d104ed6d78f49fc4c5be79ba768e8900517cb845e3f1ab4d9c5a7e46",
  verbose: true,
  debug: true,
};
options = {
  broadcast: true,
  sign: true,
  chainId: "cf057bbfb72640471fd910bcb67639c22df9f92470936cddc1ade0e2f2e7dc4f",
  httpEndpoint: "http://127.0.0.1:8888"
};
