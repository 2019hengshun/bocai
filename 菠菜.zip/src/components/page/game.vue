<template>
    <div class="hs_container">
        <div class="hs_nav">
          <div class="hs_logo">
            <img  src="../../assets/logo.png" alt="">
          </div>
          <div class="hs_menu">
            <ul>
              <li ><img src="../../assets/image/hs_sy_1.png" alt="" ><span>首页</span></li>
              <li class="liHover"> <img src="../../assets/image/hs_bd.png" alt=""><span>爆点</span></li>
            </ul>
          </div>
          <div class="hx_center">
            <ul>
              <li><img src="../../assets/image/hs_xy.png" alt=""><span>消息</span><i class="hs_message_dot"></i></li>
              <li><img src="../../assets/image/hs_zw.png" alt=""><span>中文</span><img src="../../assets/image/hs_qh.png" alt="">
                <div class="hx_centerLang">
                  <ul>
                    <li>
                      <img src="../../assets/image/hs_zw_1.png" alt=""><span class="hx_centerLangHover">中文</span>
                    </li>
                    <li>
                      <img src="../../assets/image/hs_yw_1.png" alt=""><span>English</span>
                    </li>
                    <li>
                      <img src="../../assets/image/hs_ft_1.png" alt=""><span>繁體</span>
                    </li> 
                    <li>
                      <img src="../../assets/image/hs_hg_1.png" alt=""><span>韓國</span>
                    </li> 
                    <li>
                      <img src="../../assets/image/hs_jp_1.png" alt=""><span>日本语</span>
                    </li>                                                            
                  </ul>
                </div>
              </li>
              <li><img src="../../assets/image/hs_dl.png" alt=""><span>请登录</span><img src="../../assets/image/hs_dl_1.png" alt=""></li>
            </ul>
          </div>
        </div>
        <div class="hs_main">
            <div class="hs_main_left">
                <div class="hs_main_left_nav">
                    <div class="hs_main_left_nav_hover">
                        <span>当前投注</span>
                        <i></i>
                    </div>
                    <div>
                        <span>游戏历史</span>
                    </div>
                </div>
                <div class="hs_main_left_main" style="display:none">
                    <table>
                        <thead>
                            <tr>
                                <th>玩家</th>
                                <th>下注金额</th>
                                <th>计算倍数</th>
                                <th>利润</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>hd*****jfjj</td>
                                <td>100.00</td>
                                <td>1.00x</td>
                                <td>500.0000</td>
                            </tr>
                            <tr>
                                <td>hd*****jfjj</td>
                                <td>100.00</td>
                                <td>1.00x</td>
                                <td>500.0000</td>
                            </tr>
                            <tr>
                                <td>hd*****jfjj</td>
                                <td>100.00</td>
                                <td>1.00x</td>
                                <td>500.0000</td>
                            </tr>
                            <tr>
                                <td>hd*****jfjj</td>
                                <td>100.00</td>
                                <td>1.00x</td>
                                <td>500.0000</td>
                            </tr>
                            <tr>
                                <td>hd*****jfjj</td>
                                <td>100.00</td>
                                <td>1.00x</td>
                                <td>500.0000</td>
                            </tr>
                            <tr>
                                <td>hd*****jfjj</td>
                                <td>100.00</td>
                                <td>1.00x</td>
                                <td>500.0000</td>
                            </tr>                                                                                                                                            
                        </tbody>
                    </table>
                    <div>
                        <div class="hs_main_left_main_bottom">
                            <div>
                                <img src="../../assets/image/hs_person.png" alt="">
                                <span>12</span>
                            </div>
                            <div>
                                <img src="../../assets/image/hs_my.png" alt="">
                                <span>66.6000</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hs_main_left_main">
                    <table>
                        <thead>
                            <tr>
                                <th>期数</th>
                                <th>结果</th>
                                <th>Hash</th>
                                <th>验证</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>190015</td>
                                <td>2.00x</td>
                                <td>
                                    <a href="" style="text-decoration:underline;color:#fefefe">121314141515151512</a>
                                </td>
                                <td>
                                    <a href="" class="hs_main_left_maina">
                                        验证
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>190015</td>
                                <td>2.00x</td>
                                <td>
                                    <a href="" style="text-decoration:underline;color:#fefefe">121314141515151512</a>
                                </td>
                                <td>
                                    <a href="" class="hs_main_left_maina">
                                        验证
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>190015</td>
                                <td>2.00x</td>
                                <td>
                                    <a href="" style="text-decoration:underline;color:#fefefe">121314141515151512</a>
                                </td>
                                <td>
                                    <a href="" class="hs_main_left_maina">
                                        验证
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>190015</td>
                                <td>2.00x</td>
                                <td>
                                    <a href="" style="text-decoration:underline;color:#fefefe">121314141515151512</a>
                                </td>
                                <td>
                                    <a href="" class="hs_main_left_maina">
                                        验证
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>190015</td>
                                <td>2.00x</td>
                                <td>
                                    <a href="" style="text-decoration:underline;color:#fefefe">121314141515151512</a>
                                </td>
                                <td>
                                    <a href="" class="hs_main_left_maina">
                                        验证
                                    </a>
                                </td>
                            </tr>                                                                                                                                                                                                                              
                        </tbody>                        
                    </table>
                </div>
            </div>
            <div class="hs_main_right">
                <div class="hs_main_right_top">
                    <div class="hs_main_right_top_left">
                        <div>
                            <img src="../../assets/image/left.png" alt="">
                            <span>实时</span>
                            <div>
                                <span>最大可下注金额：</span>
                                <strong style="color:#46c1e0">859.4568.Coins</strong>
                            </div>
                        </div>
                        <div class="echart1">
                            
                        </div>
                        <div class="echart1s">
                            <span>Next Round in...</span>
                            <span>3.21s</span>
                        </div>
                    </div>
                    <div class="hs_main_right_top_right">
                        <div class="hs_main_right_top_right_nav">
                            <div class="hs_main_right_top_right_hover">
                                <span>CHH</span>
                                <i></i>
                            </div>
                            <div>
                                <span>站内币</span>
                                <img src="../../assets/image/hs_help.png" alt="" >
                                <i></i>
                            </div>
                        </div>    
                        <div class="hs_main_right_top_right_main">
                            <dl>
                                <dt>基础下注金额</dt>
                                <dd class="hs_main_right_top_right_main_1">
                                    <span>最小</span>
                                    <span>x2</span>
                                    <span>x4</span>
                                    <span>x10</span>
                                </dd>
                                <dd class="hs_main_right_top_right_main_1" style="margin:0">
                                    <span>x20</span>
                                    <span>最大</span>
                                    <input type="text" placeholder="请输入">
                                    <strong>Coins</strong>
                                </dd>
                                <dt>结算倍数</dt>
                                <dd class="hs_main_right_top_right_main_2">
                                    <input type="text" placeholder="请输入" >
                                    <strong>X</strong>
                                    <button disabled="disabled">确认下注</button>
                                </dd>
                                <dt class="hs_main_right_top_right_main_3">CHH余额：<span style="color:#3cb7d6">12.00</span><img src="../../assets/image/hs_help.png" alt=""></dt>
                                <dd class="hs_main_right_top_right_main_4">*1EOS=1CHH</dd>
                            </dl>
                            <div class="button">
                                <button disabled="disabled">充值CHH</button>
                                <button disabled="disabled" style="background:#4f505e">提现</button>
                            </div>
                        </div>                    
                    </div>
                </div>
                <div class="hs_main_right_botom">
                    <div class="hs_main_right_botom_nav">
                        <div class="hs_main_right_botom_nav_hover hs_main_right_botom_nav1">
                                <span>爆点历史统计</span>
                                <i></i>
                        </div>
                        <div class="hs_main_right_botom_nav1">
                                <span>我的下注历史</span>
                                <i></i>
                        </div>
                        <div class="hs_main_right_botom_nav_d" style="display:none">
                            <span>Vol&nbsp;:&nbsp;</span>
                            <span style="color:#e64937">245.66M</span>
                            <span class="hs_main_right_botom_nav_d_line">丨</span>
                            <span>avg(@)&nbsp;:&nbsp;</span>
                            <span style="color:#3fa4c0">5.67x</span>
                        </div>
                        <div class="hs_main_right_botom_nav_d" id="hs_main_right_botom_nav_d" style="margin-top:22px;">
                            <el-pagination
                                background
                                layout="prev, pager, next"
                                :total="1000">
                            </el-pagination>
                        </div>
                    </div>
                    <table style="display:none">
                        <thead>
                            <tr>
                                <th>下注时间</th>
                                <th>下注金额</th>
                                <th>计算倍数</th>
                                <th>计算倍数</th>
                                <th>利润</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>2019-01-15 15:30</td>
                                <td style="color:#40abc7">100.00</td>
                                <td>1.00x</td>
                                <td>有</td>
                                <td style="color:#3aa526">500.0000</td>
                            </tr>
                            <tr>
                                <td>2019-01-15 15:30</td>
                                <td style="color:#40abc7">100.00</td>
                                <td>1.00x</td>
                                <td>有</td>
                                <td style="color:#3aa526">500.0000</td>
                            </tr>
                            <tr>
                                <td>2019-01-15 15:30</td>
                                <td style="color:#40abc7">100.00</td>
                                <td>1.00x</td>
                                <td>有</td>
                                <td style="color:#3aa526">500.0000</td>
                            </tr>
                            <tr>
                                <td>2019-01-15 15:30</td>
                                <td style="color:#40abc7">100.00</td>
                                <td>1.00x</td>
                                <td>有</td>
                                <td style="color:#3aa526">500.0000</td>
                            </tr>
                            <tr>
                                <td>2019-01-15 15:30</td>
                                <td style="color:#40abc7">100.00</td>
                                <td>1.00x</td>
                                <td>有</td>
                                <td style="color:#3aa526">500.0000</td>
                            </tr>
                            <tr>
                                <td>2019-01-15 15:30</td>
                                <td style="color:#40abc7">100.00</td>
                                <td>1.00x</td>
                                <td>有</td>
                                <td style="color:#3aa526">500.0000</td>
                            </tr>
                            <tr>
                                <td>2019-01-15 15:30</td>
                                <td style="color:#40abc7">100.00</td>
                                <td>1.00x</td>
                                <td>有</td>
                                <td style="color:#3aa526">500.0000</td>
                            </tr>                                                        
                        </tbody>
                    </table>
                    <div class="echart2">

                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import echarts from "echarts";
export default {
  data() {
    return {};
  },
  methods: {},
  mounted() {
    this.myChart2 = echarts.init(document.querySelector(".echart2"));
    this.myChart2.setOption({
      // backgroundColor: "rgba(43, 62, 75, 0.5)", //背景颜色
      tooltip: {
        trigger: "axis",
        axisPointer: {
          // 坐标轴指示器，坐标轴触发有效
          type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
        }
      },
      grid: {
        //间距距离左右下
        //top: '50',
        bottom: "45",
        left: "1%",
        right: "1%",
        containLabel: true
      },
      calculable: true,
      xAxis: [
        {
          type: "category",
          boundaryGap: false,
          data: [
            "17:21",
            "",
            "17:22",
            "",
            "17:23",
            "",
            "17:24",
            "",
            "17:25",
            "",
            "17:26",
            "",
            "17:27",
            "",
            "17:28",
            "",
            "17:29",
            "",
            "17:30"
          ],
          boundaryGap: ["5%", "5%"],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#6c6c74"
            }
          }
        }
      ],
      yAxis: [
        {
          type: "value",
          axisLabel: {
            formatter: "{value} °C"
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: "#6c6c74"
            }
          },
          name: "Coins",
          nameTextStyle: {
            color: "#efefef"
          }
        },
        {
          type: "value",
          axisLabel: {
            formatter: "{value} °C"
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: "#6c6c74"
            }
          },
          name: "multiple",
          nameTextStyle: {
            color: "#efefef"
          }
        }
      ],
      series: [
        {
          name: "Coins",
          type: "bar",
          barWidth: 15,

          data: [
            60,
            70,
            80,
            114,
            56,
            66,
            77,
            118,
            20,
            60,
            70,
            80,
            114,
            56,
            66,
            77,
            118,
            20,
            100
          ],

          itemStyle: {
            normal: {
              barBorderRadius: [10, 10, 0, 0],
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: "#68e7f9"
                },
                {
                  offset: 1,
                  color: "#0e9ee5"
                }
              ])
            }
          },
          color: ["#1ba8e8"]
        },
        {
          name: "multiple",
          type: "line",
          yAxisIndex: 1,
          data: [3, 2, 1, 5, 6, 7, 9, 18, 9, 1, 3, 2, 1, 5, 6, 7, 9, 18, 9, 1],
          color: ["#f66b3b"],
          smooth: true //这句就是让曲线变平滑的
        }
      ]
    });
    this.myChart1 = echarts.init(document.querySelector(".echart1"));
    this.myChart1.setOption({
      // backgroundColor: "rgba(43, 62, 75, 0.5)", //背景颜色
      tooltip: {
        trigger: "axis",
        axisPointer: {
          // 坐标轴指示器，坐标轴触发有效
          type: "line" // 默认为直线，可选为：'line' | 'shadow'
        }
      },
      grid: {
        //间距距离左右下
        //top: '50',
        bottom: "45",
        left: "1%",
        right: "1%",
        containLabel: true
      },
      calculable: true,
      xAxis: [
        {
          type: "category",
          boundaryGap: false,
          data: ["1s", "2s", "3s", "4s", "5s", "6s", "7s", "8s", "9s"],
          boundaryGap: ["5%", "5%"],
          axisLabel: {
            show: true,
            textStyle: {
              color: "#6c6c74"
            }
          }
        }
      ],
      yAxis: [
        {
          type: "value",
          axisLabel: {
            formatter: "{value} °C"
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: "#6c6c74"
            }
          }
        }
      ],
      series: [
        {
          name: "Coins",
          type: "line",
          data: [1.0, 1.1, 1.3, 1.4, 1.44, 1.5, 1.61, 1.66, 1.9],
          itemStyle: {
            normal: {
              lineStyle: {
                width: 6 // 0.1的线条是非常细的了
              }
            }
          },
          symbol: "none", //这句就是去掉点的
          smooth: true, //这句就是让曲线变平滑的
          color: ["#1ba8e8"]
        }
      ]
    });
  }
};
</script>
<style lang="scss" scoped>
.hs_container {
  position: relative;
  width: 100%;
  //height: 100%;
  background: rgb(26, 27, 46);
  @media (min-width: 1600px) {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    .hs_nav {
      width: 17%;
      background: url("../../assets/image/hs_bg_1.png");
      position: relative;
      display: flex;
      flex-direction: column;
      .hs_logo {
        height: 140px;
        display: flex;
        align-items: center;
        justify-content: space-around;
        img {
          width: 50%;
          height: 50%;
        }
      }
      .hs_menu {
        & > ul {
          width: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
          .liHover {
            background: rgba(37, 51, 69, 0.8);
            border-radius: 4px;
          }
          li {
            width: 160px;
            height: 58px;
            padding: 11px;
            font-weight: bold;
            font-size: 20px;
            line-height: 36px;
            color: #46c1e0;
            margin: 10px;

            img {
              position: relative;
              top: -3px;
              margin-left: 30px;
            }
            span {
              margin-left: 10px;
            }
          }
        }
      }
      .hx_center {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        & > ul {
          margin-bottom: 40px;
          display: flex;
          flex-direction: column;
          align-items: center;
          color: rgb(145, 147, 156);
          & > li {
            font-weight: bold;
            font-size: 20px;
            line-height: 20px;
            position: relative;
            &:not(:first-child) {
              margin-top: 44px;
            }
            span {
              display: inline-block;
              margin: 0 10px;
            }
            img {
              position: relative;
              top: -3px;
            }
            .hs_message_dot {
              height: 8px;
              width: 8px;
              border-radius: 50%;
              position: absolute;
              background-color: rgb(70, 194, 225);
              border-radius: 10px;
              display: inline-block;
              text-align: center;
              white-space: nowrap;
              vertical-align: super;
            }
            div.hx_centerLang {
              width: 125px;
              height: 195px;
              background: url("../../assets/image/hs_rb_1.png") no-repeat;
              background-position-y: -10px;
              font-size: 16px;
              line-height: 36px;
              color: #fff;
              font-weight: normal;
              position: absolute;
              top: -180px;
              left: 105px;
              img {
                margin-left: 30px;
              }
              .hx_centerLangHover {
                color: #3b7c95;
              }
            }
          }
        }
      }
    }
    .hs_main {
      background: #1a1b2e;
      flex-grow: 1;
      display: flex;
      flex-direction: row;
      .hs_main_left {
        width: 420px;
        margin: 50px;
        background: #232436;
        display: flex;
        flex-direction: column;
        .hs_main_left_nav {
          font-size: 18px;
          line-height: 50px;
          color: #fefefe;
          display: flex;
          flex-direction: row;
          justify-content: space-around;
          background: #242a3d;
          height: 50px;
          .hs_main_left_nav_hover {
            position: relative;
            color: #46c1e0;
            i {
              width: 0;
              height: 0;
              border-width: 0 8px 8px;
              border-style: solid;
              border-color: transparent transparent #46c1e0; /*透明 透明  灰*/
              position: absolute;
              left: 44%;
              bottom: 0;
            }
          }
        }
        .hs_main_left_main {
          flex-grow: 1;
          padding: 0 20px;
          display: flex;
          flex-direction: column;
          color: #fefefe;
          table {
            width: 100%;
            text-align: center;
            th {
              font-size: 16px;
              line-height: 36px;
              color: #94959a;
              border-bottom: 1px solid #1a1b2e;
            }
            td {
              font-size: 14px;
              line-height: 36px;
            }
          }
          & > div {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            .hs_main_left_main_bottom {
              display: flex;
              flex-direction: row;
              justify-content: space-around;
              margin-bottom: 20px;
              div {
                display: flex;
                flex-direction: row;
                align-items: center;
                padding: 8px 9px;
                background: #343546;
                img {
                  width: 30px;
                  height: 24px;
                  margin-right: 10px;
                }
                span {
                  flex-grow: 1;
                  text-align: center;
                  padding-left: 10px;
                  border-left: 1px solid #1a1b2e;
                }
              }
              & > :first-child {
                width: 140px;
                height: 42px;
              }
              & > :last-child {
                width: 190px;
                height: 42px;
              }
            }
          }
          .hs_main_left_maina {
            font-size: 14px;
            line-height: 42px;
            padding: 4px 10px;
            color: #3b7c95;
            border: 1px solid #3b7c95;
          }
        }
      }
      .hs_main_right {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        .hs_main_right_top {
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          .hs_main_right_top_left {
            width: 640px;
            height: 550px;
            margin-top: 50px;
            display: flex;
            flex-direction: column;
            background: #232436;
            position: relative;
            & > :first-child {
              height: 55px;
              background: #242a3d;
              border-radius: 10px 10px 0 0;
              display: flex;
              flex-direction: row;
              align-items: center;
              img {
                margin-left: 20px;
              }
              & > span {
                font-size: 20px;
                line-height: 55px;
                color: #fefefe;
                margin-left: 18px;
              }
              & > div {
                flex-grow: 1;
                display: flex;
                flex-direction: row;
                justify-content: flex-end;
                padding-right: 20px;
                font-size: 16px;
                line-height: 50px;
                color: #7f8189;
              }
            }
            .echart1 {
              width: 100%;
              height: calc(100%);
            }
            .echart1s {
              width: 100%;
              position: absolute;
              top: 50%;
              display: flex;
              flex-direction: column;
              font-weight: bold;
              color: #fff;
              font-size: 26px;
              line-height: 44px;
              text-align: center;
              align-items: center;
              transform: translateY(-50%);
            }
          }
          .hs_main_right_top_right {
            width: 320px;
            height: 550px;
            margin-top: 50px;
            margin-right: 45px;
            background: #232436;
            .hs_main_right_top_right_nav {
              font-size: 18px;
              line-height: 50px;
              color: #fefefe;
              display: flex;
              flex-direction: row;
              justify-content: space-around;
              background: #242a3d;
              height: 50px;
              & > div {
                position: relative;
              }
              img {
                position: absolute;
                right: -40px;
                top: 16px;
              }
              .hs_main_right_top_right_hover {
                position: relative;
                color: #46c1e0;
                i {
                  width: 0;
                  height: 0;
                  border-width: 0 8px 8px;
                  border-style: solid;
                  border-color: transparent transparent #46c1e0; /*透明 透明  灰*/
                  position: absolute;
                  left: 44%;
                  bottom: 0;
                }
              }
            }
            .hs_main_right_top_right_main {
              dl {
                display: flex;
                flex-direction: column;
                color: #a8a8ad;
                padding: 0 18px;
                margin: 0 0 16px;
                dt {
                  font-size: 16px;
                  line-height: 16px;
                  margin: 25px 0;
                  color: #fefefe;
                  border-left: 2px solid #d3d3d7;
                  padding-left: 7px;
                }
                .hs_main_right_top_right_main_1 {
                  font-size: 14px;
                  line-height: 28px;
                  display: flex;
                  flex-direction: row;
                  align-items: center;
                  justify-content: space-between;
                  margin-bottom: 24px;
                  span {
                    display: inline-block;
                    width: 48px;
                    height: 28px;
                    border: 1px solid #dbdbde;
                    text-align: center;
                  }
                  input {
                    text-align: center;
                    width: 60px;
                    color: #65666f;
                    -web-kit-appearance: none;

                    -moz-appearance: none;
                    border: none;
                    outline: 0;
                    background-color: transparent;
                    border-bottom: 1px solid #65666f;
                  }
                  strong {
                    position: relative;
                    left: -15px;
                    color: #e0e0e2;
                  }
                }
                .hs_main_right_top_right_main_2 {
                  input {
                    text-align: center;
                    width: 100px;
                    color: #65666f;
                    -web-kit-appearance: none;

                    -moz-appearance: none;
                    border: none;
                    outline: 0;
                    background-color: transparent;
                    border-bottom: 1px solid #65666f;
                  }
                  button {
                    width: 108px;
                    height: 34px;
                    font-size: 16px;
                    line-height: 34px;
                    color: #fff;
                    margin: 0;
                    padding: 0;
                    background: #3cb7d6;
                    border: none;
                    border-radius: 5px;
                    float: right;
                  }
                  strong {
                    color: #fff;
                    margin-left: 3px;
                  }
                }
                .hs_main_right_top_right_main_3 {
                  position: relative;
                  img {
                    position: absolute;
                    right: 0px;
                    top: 0px;
                  }
                }
                .hs_main_right_top_right_main_4 {
                  font-size: 16px;
                  line-height: 16px;
                  letter-spacing: 5px;
                }
              }
              .button {
                padding: 0 23px;
                button {
                  width: 100%;
                  height: 40x;
                  font-size: 16px;
                  line-height: 40px;
                  color: #fff;
                  margin: 0;
                  margin-bottom: 24px;
                  padding: 0;
                  background: #3cb7d6;
                  border: none;
                  border-radius: 5px;
                }
              }
            }
          }
        }
        .hs_main_right_botom {
          width: 1020px;
          height: 380px;
          margin-top: 50px;
          background: #232436;
          .hs_main_right_botom_nav {
            font-size: 18px;
            line-height: 50px;
            color: #fefefe;
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            background: #242a3d;
            height: 50px;
            .hs_main_right_botom_nav1 {
              width: 240px;
              text-align: center;
            }
            .hs_main_right_botom_nav_hover {
              position: relative;
              color: #46c1e0;
              i {
                width: 0;
                height: 0;
                border-width: 0 8px 8px;
                border-style: solid;
                border-color: transparent transparent #46c1e0; /*透明 透明  灰*/
                position: absolute;
                left: 44%;
                bottom: 0;
              }
            }
            .hs_main_right_botom_nav_d {
              flex-grow: 1;
              display: flex;
              flex-direction: row;
              justify-content: flex-end;
              align-items: center;
              .hs_main_right_botom_nav_d_line {
                color: #1a1b2e;
              }
              margin-right: 20px;
            }
          }
          table {
            width: 100%;
            text-align: center;
            color: #fefefe;
            th {
              font-size: 16px;
              line-height: 36px;
              color: #94959a;
              border-bottom: 1px solid #1a1b2e;
            }
            td {
              font-size: 16px;
              line-height: 39px;
            }
          }
          .echart2 {
            width: 100%;
            height: calc(100% - 50px);
            margin-top: 15px;
          }
        }
      }
    }
  }
  @media (max-width: 992px) and (min-width: 767px) {
    p {
      color: yellow;
    }
  }
  @media (max-width: 768px) and (min-width: 577px) {
    p {
      color: blue;
    }
  }
  @media (max-width: 576px) {
    p {
      color: green;
    }
  }
}
</style>

<style>
#hs_main_right_botom_nav_d .el-pagination.is-background .el-pager li {
  background-color: transparent;
  border: 1px solid;
}
</style>

